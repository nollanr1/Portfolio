# osp_lab4_nollanr1
Recursive file search, Due 5/22.

How to use:
Program will not run without three arguments: No more, no less.

First argument is the program name to launch program.
Second argument is the "search term".
Third argument is the starting directory.

If search term contains spaces, place it in quotes:
bash will recognize and discard the quotes, keeping the whitespace.

For best results, have parent directory be one that
immediately contains many subdirectories:
threading is split on the first subdirectory.
Example: Calling file_search_threaded on a directory
with only two subdirectories only spawns two threads,
regardless of how many subdirectories they contain.
Calling it on one that has at least four spawns up to four threads.
As such, performance gains will be minimal on filesystems with
significantly lopsided filetrees.

Note that symbolic links break this program.
