#include <stdio.h>
#include <stdlib.h>
#include <string.h> //For string functions
#include <sys/time.h>
#include <time.h> //I need these two to measure how long this takes.
#include <sys/types.h>
#include <errno.h>
#include <dirent.h> //For directory reading/changing functions


void recursiveSearch(char *currentDirectoryName, char *searchTerm);


int main(int argc, char *argv[])
{
	//Constructing the time measuring things are free, but the rest is not.
	//I basically pilfered this section from my hw2 code.
	struct timespec startTime, endTime;
	long elapsedSec = 0;
	int elapsedNano = 0;
	clock_gettime(CLOCK_MONOTONIC_RAW, &startTime);
	//CLOCK_MONOTONIC_RAW is suppose to be the least shaky, I think.

	if(argc != 3)
	{
		printf("Usage: file_search <search term> <starting directory>\n");
		printf("Note that starting directory is an absolute path.\n");
		return(0);
	}

	//Make sure argument starts with /, and if it ends in /, toss /
	if(argv[2][0] != '/')
	{
		printf("Starting point for search must be an absolute path, starting with \"/\"\n");
		return(0);
	}
	if(argv[2][(strlen(argv[2]) - 1)] == '/')//That's the end of string position
		argv[2][(strlen(argv[2]) - 1)] = '\0';//So push it back one

	DIR *directoryTest = opendir(argv[2]);
	if(directoryTest == NULL) //If directory can't be opened for reasons
	{
		switch(errno)
		{
			case EACCES:
				printf("Permission to access %s is denied.\n", argv[2]);
				break;
			case EBADF:
				printf("%s is not a valid file descriptor.\n", argv[2]);
				break;
			case EMFILE:
				printf("This process has opened too many file descriptors.\n");
				break;
			case ENFILE:
				printf("The system-wide limit on the total number of open files has been reached.\n");
				break;
			case ENOENT:
				printf("%s does not exist.\n", argv[2]);
				break;
			case ENOMEM:
				printf("Insufficient memory to complete operation.\n");
				break;
			case ENOTDIR:
				printf("%s is not a directory.\n", argv[2]);
			default:
				printf("An unexpected error occurred when attempting to access %s\n", argv[2]);
				break;
		}
		return(errno);
	}
	else
		closedir(directoryTest); //Don't need more open than needed...

	//BACKBONE OF THE CODE, RIGHT HERE:
	recursiveSearch(argv[2], argv[1]);

	//This part really is just copy-paste from my HW2 code
	clock_gettime(CLOCK_MONOTONIC_RAW, &endTime);
	elapsedSec = (long)(endTime.tv_sec - startTime.tv_sec);
	elapsedNano = (endTime.tv_nsec - startTime.tv_nsec);

	if(elapsedNano <0)
	{
		elapsedSec--;
		elapsedNano += 999999999;
	}
	printf("Time taken: ");
	if(elapsedSec > 0) //Don't spam the user with seconds if zero
		printf("%ld seconds, ", elapsedSec);
	printf("%d nanoseconds.\n", elapsedNano);


	return(0);
}//End int main()

//Note that "search term" is a pointer to argv[1].
//Or is identical to argv[1], if argv[1] is a pointer to some array.
//The terminology is a bit... fuzzy.
void recursiveSearch(char *currentDirectoryName, char *searchTerm)
{
	DIR *currentDirectory = opendir(currentDirectoryName);


	if(currentDirectory == NULL) //If the directory can't be accessed, bail
	{
		return;
	}
	//Otherwise, proceed with setup
	char *isFound = NULL;
	char *fullPathName = NULL; //I need an arbitrary length, I'll use realloc


	struct dirent *currentFile;
	currentFile = readdir(currentDirectory); //Returns a pointer to first file
	while(currentFile != NULL) //Not Do...While, which would break in empty DIR
	{
		if(!(strcmp(currentFile->d_name, "."))) //If name is"."
		{
			;
		} //Skip it
		else if(!(strcmp(currentFile->d_name, ".."))) //If name is".."
		{
			;
		} //Skip that too
		else
		{
			isFound = strstr(currentFile->d_name, searchTerm);
			if(isFound != NULL) //That is, the target was found
			{//Since this doesn't print absolute path,
			//I need to print the current directory first.
			//And replace that forward slash.
				printf("%s/", currentDirectoryName);
				//Then I print the name of the file
				printf("%s", currentFile->d_name);
				if(currentFile->d_type == DT_DIR)//Directory check
					printf(":"); //If it's a directory, print a ":"
				printf("\n"); //And the ever-needed newline
			}//End "if(isFound != NULL)"

			if(currentFile->d_type == DT_DIR)
			{ //So, this is a depth-first search, not breadth-first.
				fullPathName = strdup(currentDirectoryName);
//Size Here: (length in bytes of currentDirectory + length in bytes of FileName)
//Plus an extra two bytes for "/" and a null terminator.
//My math might be a little off, but if it is, It's a little over,
//which is far preferable to being a little under.
				fullPathName = realloc(fullPathName, (((sizeof(char))*(strlen(currentDirectoryName))) + (2 * sizeof(char))  + ((sizeof(char))*(strlen(currentFile->d_name)))));
				strcat(fullPathName, "/");
				strcat(fullPathName, currentFile->d_name);
				//Now fullPathName actually is the full path name
				//Which we pass to recursive search
				recursiveSearch(fullPathName, searchTerm);
				//And free when we're finished with it.
				free(fullPathName);
			}//End "if(currentFile->d_type == DT_DIR)"
		}//End "else"
		currentFile = readdir(currentDirectory); //Next file, please?
	}//End "while(currentFile != NULL)"
	closedir(currentDirectory);

	return;
}
