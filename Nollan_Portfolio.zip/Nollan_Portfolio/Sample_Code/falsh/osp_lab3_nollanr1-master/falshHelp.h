#ifndef NOLLAN_FALSHFUNCTIONS_HELP
#define NOLLAN_FALSHFUNCTIONS_HELP

#include <stdio.h>

/*
falshHelp(): Dumps the help text to the screen.
I don't know how to replicate the nice man pages,
and I'm not allowed to call exec for this:
the help must be built in.
*/
void falshHelp()
{
	/* exit description */
	printf("\n\"exit\": Exits the falcon shell. Also accepts \"Exit\"\n");
	printf("Usage: exit\n");
	printf("Exit takes highest priority, and ignores anything else on the line.\n");
	/* pwd description */
	printf("\n\"pwd\": Print working directory.\n");
	printf("Usage: pwd\n");
	printf("Prints the absolute path to the current directory.\n");
	printf("Takes no additional arguments.\n");
	/* cd description */
	printf("\n\"cd\": Change directory.\n");
	printf("Usage: cd <directory>\n");
	printf("Attempts to change to the indicated directory.\n");
	printf("If no argument is provided, returns to home directory.\n");
	printf("(Use argument \"/..\" to return to parent directory.)\n");
	/* setpath description */
	printf("\n\"setpath\": sets the path to search along for programs.\n");
	printf("Usage: setpath <directory> <directory> ... <directory>\n");
	printf("setpath defines where falsh will look when searching for programs.\n");
	printf("It accepts an arbitrary number of paths, and will search them in order.\n");
//	printf("Note that it is possible to define no paths. This is typically bad.\n");
	printf("At least one path must be set.\n");
	printf("By default, the path is set to /bin.\n");
	printf("Also note that setpath overwrites any previously stored paths!\n");
	/* help description */
	printf("\n\"help\": Prints this help text to the screen.\n");
	printf("Can also be invoked with Help (although not HELP or hElP...)\n");
	printf("Can also be invoked from outside of falsh by invoking with falsh -h\n");

	/* redirection description */
	printf("\nBasic redirection is supported.\n");
	printf("By ending any command with \" > [filename]\"\n");
	printf("Output from the program will be placed in filename.out\n");
	printf("Error output will be placed in filename.err\n");
	printf("Note that these files will be overwritten if they already exist!\n");
	printf("(Any name can be substituted for [filename]).\n\n");

	return;
}


#endif /* NOLLAN_FALSHFUNCTIONS_HELP */
