# osp_lab3_nollanr1
This is not a good sign. If my other classes are heavy, I'm doomed.
