#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h> //For strcmp()
#include <sys/wait.h> //For forking
#include <errno.h> //So we can let users know *what* went wrong for some things
#include "argumentProcessor.h" //Breaks up the arguments, nice & neat
#include "falshFunctions.h" //The built in functions
#include "falshHelp.h" //The help manual

int main(int argc, char *argv[])
{
	if (argc > 2)
	{
		printf("Usage: falsh\nfalsh -h\nfor manual.\n");
		exit(1);
	}
	else if (argc == 2)
	{
		if(!(strcmp("-h", argv[1]))) //If argv 1 is "-h", show help
		{
			falshHelp();
			return(0); //It just cats, so it'll stay.
		}
		else
			printf("Usage: falsh\nfalsh -h (for manual.)\n");
		exit(2);
	}

	else // Begin the shell in earnest
{ //Putting the brackets down here for space economy.
	//Setup of variables

	char **argumentValues = NULL; //Pointer to an array of pointers
	char userCommand[256]; //I'm putting this on the stack because why not.
	int argumentCount = 0;
	int forkCheck = 0; //To break a loop
	int forkValue = -1; //To wait for exec()
	int pipeFlag = 0;

	int backupSTDOUT = dup(STDOUT_FILENO);
	int backupSTDERR = dup(STDERR_FILENO);
	//If I'm reading this right, this gives us copies of the iostreams

	char **reallocCheck = NULL; //If realloc fails, I need this to free() old mem
	//Also, setting up the filePath linked list

	struct searchPath *filePathHead = malloc(sizeof(struct searchPath));
	if(filePathHead == NULL)
	{
		fprintf(stderr, "Critical Error: Could not initialize falsh\n");
		exit(-1);
	}
	strcpy(filePathHead->thisPath, "/bin"); //Now /bin/ is our filepath.
	filePathHead->next = NULL; //Also, there are no other paths at the moment.
	//And I can't define that in the struct itself, I have to do it manually.
	struct searchPath *filePathSearcher = filePathHead;
	//This is the traverser pointer

	//Setup complete, begin main shell
	while(1) //Forever
{
//Inside that else statement, but still back here for space economy

	if(argumentValues != NULL) //If the argument array isn't empty
	{
		argumentDestructor(argumentValues, argumentCount); //Free it
		argumentValues = NULL; //Set it to NULL, because destuctor doesn't
	}
	printf("> "); //This is our prompt appearance
	if(NULL == fgets(userCommand, 256, stdin)) //Get user input.
	{//NULL is returned on EOF. In bash, that means logout, so...
		printf("exit\n");
		return(0);
	}
	if(userCommand[0] == '\n') //If the first char was a newline, is empty
	{
		argumentCount = 0;
//If we don't note this, it tries to free the previous memory a second time
	}
	else //We got an actual command
	{
		argumentValues = argumentConstructor(userCommand, &argumentCount);
		//Now we have a pointer to our arguments, and how many there are
		//*BEFORE* running these other functions. Should work...


/******* EXIT FUNCTION *********/
		if(!(strcmp("exit", argumentValues[0]) && strcmp("Exit", argumentValues[0])))
		{//That is, if the argument is "exit" or "Exit", via tortured logic
			return(0); //Capital or not, and ignoring follow arguments.
		}
			//Naturally, this means user can't run a custom "exit" but w/e.


/****** REDIRECT CHECK/FUNCTION ******/
		if(argumentCount > 2) //If we have enough arguments for a redirect
		{

			if(!(strcmp(">", argumentValues[argumentCount - 2])))
			{ //It's not -1, because arrays start at [0], not [1].
				pipeFlag = outputShuffler(argumentValues, argumentCount, pipeFlag, backupSTDOUT, backupSTDERR);
			}
		}




/******* PWD FUNCTION **********/
		if(!(strcmp("pwd", argumentValues[0])))
			falshPWD(argumentValues, argumentCount);

/******** CD FUNCTION **********/
		else if(!(strcmp("cd", argumentValues[0])))
			falshCD(argumentValues, argumentCount, pipeFlag);

/******* SETPATH FUNCTION ******/
		else if(!(strcmp("setpath", argumentValues[0])))
		{
			if ((argumentCount < 2) ||((pipeFlag == 1)&&(argumentCount <4)))
				fprintf(stderr, "setpath requires at least one argument.\n");
			else
				falshSetPath(argumentValues, argumentCount, filePathHead, pipeFlag);
		}

/******* HELP FUNCTION *********/
		else if(!(strcmp("help", argumentValues[0]) && strcmp("Help", argumentValues[0])))
		{ //Like exit, this is the most forgiving command (they'll need it?)
			falshHelp();
		}


/******* FORKIN' HECK *********/
		else //Check the filepath locations for the command, fork & exec
		{
			forkCheck = 0;
			//Now, we need to add a NULL so that exec will work.
			if(pipeFlag == 1)
			{//Then theres args on the line that will break the exec
				argumentCount -= 1; //So remove the last argument
				free(argumentValues[argumentCount]); //And free two
				free(argumentValues[argumentCount - 1]);
				argumentValues[argumentCount - 1] = NULL;
				//And make the last one NULL, as per specs
			}
			else
			{//Then redirection isn't an issue, but we still need a NULL.
				//Add space for said NULL:
				reallocCheck = realloc(argumentValues, (sizeof(char*)) * (argumentCount + 1));
				if(reallocCheck != NULL)
				{
					argumentCount++;
					argumentValues = reallocCheck; //As per realloc specs
					//Now we have added another argument (Soon to be our NULL)
					argumentValues[argumentCount - 1] = NULL;
					//Now our **char should be execv worthy!
					reallocCheck = NULL; //For the next time
				}
				else
				{
					fprintf(stderr,"Failure: Could not spare even a byte of VRAM.\n");
					goto REALLOC_FAIL_BREAK; //I'm sorry.
				}
			}

			//Now, we see if the file exists along any of the set filepaths
			while((filePathSearcher != NULL) && (forkCheck == 0))
			{
				strcpy(userCommand, filePathSearcher->thisPath);
				strcat(userCommand, "/"); //For that one bit...
				strcat(userCommand, argumentValues[0]);
				//Now we have the complete file path. But does it exist?
				if(!access(userCommand, F_OK)) //Does it exist
				{
					if(!access(userCommand, X_OK)) //Can it be executed
					{
						forkCheck = 1; //Which breaks the while() loop
						forkValue = fork();
						if(forkValue < 0)
						{
							fprintf(stderr, "Failed to fork for %s\n", userCommand);
						}
						else if(forkValue > 0)//Parent process
						{
							wait(NULL); //Wait for child (only 1 child, so NULL)
						}
						else //Child process
						{//The environment is inherited, right?
							execv(userCommand, argumentValues);
						}
					}
				}
				if(forkCheck < 1)//Otherwise user gets failmessage on success.
					filePathSearcher = filePathSearcher->next; //Is it in another path?
			}
			if(filePathSearcher == NULL)
				printf("%s either does not exist on $PATH or execution is forbidden.\n", argumentValues[0]);
			filePathSearcher = filePathHead; //Reset for next run
		}//End FORKIN'HECK
		REALLOC_FAIL_BREAK: //It was the only way I could see.





		if(forkValue == 0) //This is a child process, should be impossible, but
		{//Better safe than sorry.
			fclose(stdout);
			fclose(stderr);
			return(0);
		}

		if(pipeFlag == 1) //That is, we've been using a file instead of stdout
		{
			pipeFlag = outputShuffler(argumentValues, argumentCount, pipeFlag, backupSTDOUT, backupSTDERR);
		}
	} // End of "else //We got an actual command"


}//End of "while(1) //Forever"


}// End of "else // Begin the shell in earnest"

	return (-1); //This shouldn't be reachable but whatever

}// End of "int main".
