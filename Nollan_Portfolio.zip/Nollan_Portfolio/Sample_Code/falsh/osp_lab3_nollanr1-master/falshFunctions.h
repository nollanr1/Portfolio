#ifndef NOLLAN_FALSHFUNCTIONS
#define NOLLAN_FALSHFUNCTIONS


#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h> //For redirection, specifically
#include <unistd.h>
#include <sys/types.h>
#include <string.h> //For strcmp()
#include <errno.h> //So we can let users know *what* went wrong for some things



/* struct searchPath: This way, an arbirary number of paths can be stored.
They're not persistent, however.
This seems to be in line with the design document:
"The path when falsh launches should contain only /bin"
*/
struct searchPath
{
	char thisPath[256]; //Because I'm sick of being efficient. Also, deadlines.
	struct searchPath *next;
};


/******* REDIRECTION FUNCTION ******/
//Output Shuffler - redirects to and from stdout and stderr and files as needed.
//Changes fileFlag between 1 and 0 to indicate the current state.
//0 is stdout & stderr, 1 is files.
//Returns the new fileFlag value - if the user doesn't take advantage,
//That's on them.
int outputShuffler(char **argumentValues, int argumentCount, int outputFlag, int backupSTDOUT, int backupSTDERR)
{
	if(outputFlag == 0) //Switching from standard out to file output.
	{
		char pathStorage[256];
		char *testString = argumentValues[argumentCount - 1];
		strncpy(pathStorage, testString, 250);
		strcat(pathStorage, ".txt"); // This should work always...
		close(STDOUT_FILENO); //I want these as close together as possible.
		open(pathStorage, O_RDWR | O_TRUNC | O_CREAT, 00644);
//Those numbers there should mean: User can do all, others can only read.

		strncpy(pathStorage, testString, 250);
		strcat(pathStorage, ".err");
		close(STDERR_FILENO);
		open(pathStorage, O_RDWR | O_TRUNC | O_CREAT, 00644);

		outputFlag = 1;
	}
	else if(outputFlag == 1) //Switching back to standard output.
	{ //Good heavens, I hope this works.
		close(STDOUT_FILENO);
		dup2(backupSTDOUT, STDOUT_FILENO); //Copies backup to STDOUT_FILENO
		close(STDERR_FILENO);
		dup2(backupSTDERR, STDERR_FILENO);
		//My big fear is that this somehow leaves loose open files around.
		//Probably not, but fear doesn't have to be rational.
		outputFlag = 0;
	}
	else
	{
		printf("Output flag is unexpected value. Data corruption likely.\n");
	}

	return(outputFlag);
}


/******* PWD FUNCTION **********/
int falshPWD(char **argumentValues, int argumentCount)
{
	char *genericBuffer = NULL;
	genericBuffer = getcwd(genericBuffer, 0); //Linux auto-mallocs this
	if(genericBuffer == NULL)
	{
		fprintf(stderr, "Cannot load directory: VRAM expended.\n");
		return(-1);
	}
	else
	{
		fprintf(stdout, genericBuffer);
		free(genericBuffer); //As per the manual for getcwd()
		genericBuffer = NULL;
	}
	return(0);
}

/******** CD FUNCTION **********/

int falshCD(char **argumentValues, int argumentCount, int fileFlag)
{

	errno = 0; //Just in case
	int chdirResult = 0;
	if(fileFlag == 1) //Accounting for extra arguments.
		argumentCount -= 2;

	if(argumentCount == 1) //No value, so go home
	{
		chdirResult = chdir(getenv("HOME"));
		//That was easier than expected.
	}
	else if(argumentCount == 2) //Try to follow given path
	{
		/*This was also surprisingly easy.*/
		chdirResult = chdir(argumentValues[1]);
	}
	else
	{
		printf("Usage: cd <directoryName>\n");
		printf("Type \"help\" for more details.\n");
		return(1);
	}

	if(chdirResult == -1) //What chdir returns on failure
	{
	/*Go thru list of possible errors, tell user if one happened*/
		fprintf(stderr, "Could not cd: ");

		switch(errno)
		{
		case EACCES:
			fprintf(stderr, "Search permission is denied.\n");
			break;
		case EFAULT:
			fprintf(stderr, "%s points outside your accessible address space.\n", argumentValues[1]);
			break;
		case EIO:
			fprintf(stderr, "An I/O error occurred.\n");
			break;
		case ELOOP:
			fprintf(stderr, "Too many symbolic links were encountered.\n");
			break;
		case ENAMETOOLONG:
			fprintf(stderr, "Path name is too long.\n");
			break;
		case ENOENT:
			fprintf(stderr, "The directory specified does not exist.\n");
			break;
		case ENOMEM:
			fprintf(stderr, "Main kernel memory is depleted.\n");
			break;
		case ENOTDIR:
			fprintf(stderr, "A component of path given is not a directory.\n");
			break;
		default:
			fprintf(stderr, "An unexpected error occured: Error value: %d", errno);
			break;
		}

	}


	return(chdirResult);
}

/******* SETPATH FUNCTION ******/
int falshSetPath(char **argumentValues, int argumentCount, struct searchPath *head, int fileFlag)
{
	struct searchPath *listRunner = head;
	int failFlag = 0; //Return value, is set to 1 if an allocate fails
	if(fileFlag == 1) //Then there are two extra arguments we can ignore
		argumentCount -= 2;
/* How this part works:
	Run through each argument (except the ends, which we've marked off already)
	put it in the list. If there's another argument, malloc more space.
	Then put the next argument in the list.
	If there is more space, but no more arguments, start free()ing
	the remainder of the list.*/
	for(int i = 1; i < argumentCount; i++)
	{
		strcpy(listRunner->thisPath, argumentValues[i]);
		//If the user ended the path with "/", account for that
		if(listRunner->thisPath[strlen(listRunner->thisPath) - 1] == '/')
		{
			listRunner->thisPath[strlen(listRunner->thisPath) - 1] = '\0';
		}

		if((listRunner->next == NULL)&&(i<(argumentCount)))
		{//If we need more space that isn't allocated
			listRunner->next = malloc(sizeof(struct searchPath));
			if(listRunner->next == NULL)
			{
				fprintf(stderr, "Could not allocate for filepaths %s or beyond: VRAM exhausted\n", argumentValues[i+1]);
				i = argumentCount; //Breaks the loop before segfault
				failFlag = 1;
			}
			else
			{
				listRunner = listRunner->next;
				listRunner->next = NULL;
			}
		}
		else if( listRunner->next != NULL) //If space is already allocated
		{
			listRunner = listRunner->next; //Use it
		}
	}
//This whole thing overallocates by one, though.
//I'll account for it here:
//Now, where we free() the old list.
	struct searchPath *listTrailer = head;
	while(listTrailer->next != listRunner) //Find the old cutoff point
	{
		listTrailer = listTrailer->next;
	}
	listTrailer->next = NULL; //Cut the list here

	while(listRunner != NULL)
	{
		listTrailer = listRunner;
		listRunner = listRunner->next;
		free(listTrailer); //That should work, for realsies this time.
	}

/********** HERE BE DEAD CODE ***********/
/*	if(listRunner->next != NULL) //If our old list was larger, free() space
	{
		struct searchPath *listTrailer;
		listTrailer = listRunner;
		listRunner = listRunner->next;
		listTrailer->next = NULL;
		listTrailer = listRunner;
		while(listRunner->next != NULL)
		{
			listRunner = listRunner->next;
			free(listTrailer);
			listTrailer->next = NULL; //Forgot this at first...
			listTrailer = listRunner;
		}
		free(listTrailer); //And that should do it!
	}*/
/********** NEVER YE MIND THAT DEAD CODE*****/

	return(failFlag); //0 if success, 1 if failure
}


#endif /*NOLLAN_FALSHFUNCTIONS*/
