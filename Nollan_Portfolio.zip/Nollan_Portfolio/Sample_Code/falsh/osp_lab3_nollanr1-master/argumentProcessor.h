#ifndef argumentProcessor_NOLLAN_FALSH_FUNCTIIONS
#define argumentProcessor_NOLLAN_FALSH_FUNCTIIONS

#include <stdio.h>
#include <stdlib.h>
#include <string.h> //For strlen()

/*
argumentConstructor:
Takes a string of the users areguments, plus an int to edit by reference
Returns a pointer to an array of pointers that point to the arguments.
Also edits the argument count to equal the number of arguments.
On failure, returns a NULL pointer.
*/

char **argumentConstructor(char userCommand[256], int *argumentCount)
{
	FILE *stringStream; //To read from this string like it's a file for wc
	stringStream = fmemopen(userCommand, strlen(userCommand), "r");
	//Which is what the fmemopen() command is for

	int inputLength = strlen(userCommand);
	//To keep from spilling out of the array
	inputLength--; //It counts some sort of extra whitespace...?

	if(stringStream == NULL)
	{
		fprintf(stderr, "Critical error: Could not process input string.\n");
		return(NULL);
	}


	char currentChar; //First things first: how many words?
	long wordSize = 0; //Then later: How big are said words? Long for fseek.
	short int inWord = 0; //I could use bools, but I won't this time.
	*argumentCount = 0;


	// For the length of the input string...
	for(int i = 0; i<inputLength; i++)
	{
		currentChar = fgetc(stringStream);

		if((!inWord) && (!((currentChar == ' ') || (currentChar == '\t') || (currentChar == EOF) || (currentChar == '\0'))))
		{
			(*argumentCount) += 1;
			inWord = 1;
		}
		else if((inWord) && ((currentChar == ' ') || (currentChar == '\t')))
		{
			inWord = 0;
		}
	}

	//With that processed, we now know the number of arguments.
	rewind(stringStream);
	char **argumentChart = malloc((sizeof (char*)) * (*argumentCount));
	if(argumentChart == NULL)
	{
		fprintf(stderr, "Critical error: VRAM exhausted.\n");
		return(NULL);
	}

	//Allocating space for the pointers, now we allocate for what they point to
	for(int i = 0; i < *argumentCount; i++)
	{
		wordSize = 0; //Otherwise, each word is itself plus the sum of previous
		currentChar = ' ';
		while((currentChar == ' ') || (currentChar == '\t'))
		{ //Get through the whitespace, and
			currentChar = fgetc(stringStream);
		}
		while((currentChar != ' ') && (currentChar != '\t') && (currentChar != '\n'))
		{//Those other two are EOF and '\0', for the last input.
			wordSize++;
			currentChar = fgetc(stringStream);
		}
		//So size is established, but add one for the null pointer
		argumentChart[i] = malloc((sizeof(char)) * (wordSize + 1));
		if (argumentChart[i] == NULL) //If we're out of space
		{
			fprintf(stderr, "Critical error: VRAM exhausted ");
			fprintf(stderr, "partway through input processing.\n");
			for(int k = (i-1); k > -1; k--) //Free what we've allocated before
			{
				free(argumentChart[k]); //Free the subpointers
			}
			free(argumentChart); //Free the main pointer
			return(NULL); //And fail gracefully.
		}

		fseek(stringStream, (-(wordSize+1)), SEEK_CUR); //Back up word size amount
		//Without that +1 on word size, the first letter gets cut off.
		for(int j = 0; j < wordSize; j++)
		{
			currentChar = fgetc(stringStream);
			argumentChart[i][j] = currentChar;
			if((j + 1) == wordSize) //That is, we've finished the word
			{
				argumentChart[i][j+1] =  '\0'; //Null terminator
			}
		}
/* This is the debug block that helped me fix that fseek input
printf("WORDBACKOUT: #%d\n", i);
for(int debug = 0; debug < wordSize; debug++)
{
printf("\nCURRENTCHAR: %c\n", argumentChart[i][debug]);
}*/
	}

	//If we got here, our arguments should be good 'n' processed.
	fclose(stringStream);
	//Note that this doesn't require free()ing, since it's a stack string
	return(argumentChart); //Well, here's hoping this works!

}

/*
argumentDestructor:
Takes a pointer to an array of pointers to argument values,
and an int of how large said array is.
Frees each item indicated in the array in turn,
then frees the pointer to the array itself.
Returns nothing -
After all, if something goes wrong, the leak can't be fixed...
May as well just accept silent failure.
*/

void argumentDestructor(char **argumentValues, int argumentCount)
{
	for(int i = 0; i < argumentCount; i++)
	{
		if(argumentValues[i] != NULL)
			free(argumentValues[i]);
	}

	free(argumentValues);

	return;
}



#endif /* falshArgumentProcessor.h*/
