package main

import ("fmt"; "flag"; "os"; "bufio"; "strings"; "regexp")

type tokenStruct struct {
	dasLexeme	string
	dasType		string
	dasValue	string
	dasToken	string
	dasRaw		[]string
}

/****** tokenProcessor:
Takes the raw Lexeme, identifies its properties, and returns the processed token.
Takes a string (the Lexeme)
Teturns a tokenStruct (the processed token.)
This is the real guts of the program. *****/
func tokenProcessor(dasRaw string, sourceSlice []string) (tokenStruct) {

	var buildyToken tokenStruct
	buildyToken.dasRaw = sourceSlice
	buildyToken.dasLexeme = ""
	buildyToken.dasType = ""
	buildyToken.dasValue = ""
	buildyToken.dasToken = ""
	//If LONGEST doesn't hold between functions, I'll have to set it here
	//BEGIN, WRITE, and END Lexemes
	if((dasRaw == "BEGIN") || (dasRaw == "WRITE") || (dasRaw == "END")) {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = dasRaw

	//Single Character Constants, plus assign

	} else if(dasRaw == ":") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "COLON"
	} else if(dasRaw == "^") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "POWER"
	} else if(dasRaw == "*") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "TIMES"
	} else if(dasRaw == "/") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "DIVISION"
	} else if(dasRaw == "+") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "PLUS"
	} else if(dasRaw == "-") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "MINUS"
	} else if(dasRaw == "(") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "LPAREN"
	} else if (dasRaw == ")") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "RPAREN"
	} else if(dasRaw == ".") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "POINT"
	} else if(dasRaw == "<=") {
		buildyToken.dasLexeme = dasRaw
		buildyToken.dasToken = "ASSIGN"


	//Variables
	} else if(((dasRaw[0] == '$') || (dasRaw[0] == '#') || (dasRaw[0] == '%')) &&
	(len(dasRaw) > 1)) {
		buildyToken.dasLexeme = dasRaw[1 : (len(dasRaw))]
		dasRaw = dasRaw + "\n" //To make regexp.Match more easily usable
		if isMatch, _ := (regexp.Match("[[:lower:]]+([[:lower:]]|[[:digit:]])*\\n",
		[]byte(dasRaw[1 : len(dasRaw)]))); isMatch { //isMatch only has scope in this IF statement
			buildyToken.dasLexeme = dasRaw[ 1: (len(dasRaw) - 1)]
			buildyToken.dasToken = "ID"
			if(dasRaw[0] == '$') {
				buildyToken.dasType = "STRING"
			} else if(dasRaw[0] == '#') {
				buildyToken.dasType = "INT"
			} else { //Else it must be a real
				buildyToken.dasType = "REAL"
			}
		} else { //If it's not a match, we have an illegal lexeme
			buildyToken.dasLexeme = dasRaw[0 : (len(dasRaw) - 1)]
			buildyToken.dasToken = "Lexical_Error"
		}

	//Constants - reals first, then ints. Unfortunately, we have to mod the string a bit.
	} else {
		dasRaw = dasRaw + "\n"
		buildyToken.dasLexeme = dasRaw[0 : (len(dasRaw) - 1)]
		if isMatch, _ := (regexp.Match("[[:digit:]]+\\Q.\\E[[:digit:]]*\\n", []byte(dasRaw))); isMatch {
			buildyToken.dasToken = "REAL_CONST"
			buildyToken.dasType = "REAL"
			buildyToken.dasValue = buildyToken.dasLexeme
		} else if isMatch, _ := (regexp.Match("[[:digit:]]+\\n", []byte(dasRaw))); isMatch {
			buildyToken.dasToken = "INT_CONST"
			buildyToken.dasType = "INT"
			buildyToken.dasValue = buildyToken.dasLexeme

			/** AND IF IT'S NOT ANY OF THESE, IT'S AN ERROR! Woo! **/
		} else {
			buildyToken.dasToken = "Lexical_Error"
		}
	}

	return(buildyToken)
}

func goodBye(tokenCount int,lexicalError bool, outputFileName string) {
	fmt.Println(fmt.Sprintf("%d", tokenCount) + " Tokens produced")
	fmt.Println("Results in Output File: " + outputFileName)
	if(lexicalError) {
		fmt.Println("There was a Lexical error processing the file")
	}
}

func main() {

/******* Opening our input file *******/
	flag.Parse()
	/*Makes the command line arguments usable.
	 I do not miss having to do that by hand one bit.*/
	fmt.Println("Processing Input File: " + flag.Arg(0))
	/* We'll just take the first argument
	 If it's the file, great! If not, well.
	 This IS your script.*/
	hunterPowerFile, err := os.Open(flag.Arg(0))
	if(err != nil) { //AKA if something went wrong trying to open arg0
		fmt.Println("Error occured while attempting to open " + flag.Arg(0))
		panic(err)
	}
	defer hunterPowerFile.Close()
	readFile := bufio.NewReader(hunterPowerFile)

/******** Making our output file ********/
	var outputFileName string = flag.Arg(0)[0:(len(flag.Arg(0)) - 3)] //Funky.
	outputFileName += "out"

	outputFile, otherErr := os.Create(outputFileName) //Creating our output
	if(otherErr != nil) {
		fmt.Println("Could not create output file.")
		panic(otherErr)
	}
	defer outputFile.Close()

	/******** Making the Extra Credit file ********/
	bonusFile, xtraErr := os.Create(outputFileName[0:len(outputFileName) - 3] + "xtra")
	if(xtraErr != nil) {
		fmt.Println("Could not create extra credit output file.")
		panic(xtraErr)
	}
	defer bonusFile.Close()

/*Preparing our variables, because you can take me out of the C environment,
	but you can't take the C environment out of me.*/
	var inputString string = ""
	var currentToken tokenStruct
	var tokenCount int = 0
	var lexicalError bool = false

/******** Loading the file into memory, line by line. ********/
	for(err == nil) { //I'm expecting EoF, but other things might happen too
		inputString, err = readFile.ReadString('\n')
		for((inputString == "\n") && (err == nil)) {
			inputString, err = readFile.ReadString('\n')
		}
		if(err != nil) {
			goodBye(tokenCount,lexicalError, outputFileName)
			return //Basically, if we hit EoF while pruining newlines, quit.
		}
		/* Since tabs aren't allowed in strings, we can safely replace all tabs
		with spaces for ease-of-processing. Technically this means Tabs are
		allowed in strings, they'll just be replaced with spaces,
		but whatever.*/
		inputString = strings.Replace(inputString, "	", " ", -1) //That's a \t
		//If there's a newline, we need to be rid of it.
		//So THIS is why everyone hates unicode. This cost me an hour.
		inputString = strings.Replace(inputString, "”", "\"", -1)
		inputString = strings.Replace(inputString, "“", "\"", -1)
		if(inputString[len(inputString) - 1] == '\n') {
			inputString = inputString[:len(inputString) - 1] //Is this the bug?
		}

		for(len(inputString) > 0) { //Breaking this line into tokens
			/** Handling tokens that AREN'T strings **/
			if(inputString[0] != '"') { //That is, the rune "
				currentToken.dasRaw = strings.SplitN(inputString, " ", 2)
				currentToken.dasLexeme = currentToken.dasRaw[0]


				if(len(currentToken.dasRaw[0]) > 0) { // If token is empty, ignore it.
				currentToken = tokenProcessor(currentToken.dasRaw[0], currentToken.dasRaw)
				}

				//Setting up the next token while preventing OoB errors.
				if(len(currentToken.dasRaw) > 1) {
					inputString = currentToken.dasRaw[1]
				} else {
					inputString = ""
				}

			/** Handling Strings **/
			} else { //So this IS a string
				currentToken.dasRaw = strings.SplitAfterN(inputString, "\"", 3)
				currentToken.dasValue = ("\"" + currentToken.dasRaw[1])
				currentToken.dasToken = "STRING"
				currentToken.dasType = "STRING"

				if isMatch, _ := (regexp.Match("\"([[:digit:]]|[[:lower:]]|[[:space:]])*\"",
				[]byte(currentToken.dasValue))); isMatch {
					currentToken.dasLexeme = currentToken.dasValue[1 : (len(currentToken.dasValue) - 1)]
					currentToken.dasValue = currentToken.dasLexeme
				} else {
					currentToken.dasToken = "Lexical_Error"
					currentToken.dasLexeme = currentToken.dasValue
				}

				//Preventing OoB errors.
				if(len(currentToken.dasRaw) > 2) {
					inputString = currentToken.dasRaw[2]
				} else {
					inputString = ""
				}
			}

			//Output processed token into output file
			//Basic Literal Terminals
			if( (currentToken.dasLexeme == "BEGIN") ||
			(currentToken.dasLexeme == "WRITE") ||
			(currentToken.dasLexeme == "END") ||
			(currentToken.dasLexeme == ":") ||
			(currentToken.dasLexeme == "^") ||
			(currentToken.dasLexeme == "*") ||
			(currentToken.dasLexeme == "/") ||
			(currentToken.dasLexeme == "+") ||
			(currentToken.dasLexeme == "-") ||
			(currentToken.dasLexeme == "(") ||
			(currentToken.dasLexeme == ")") ||
			(currentToken.dasLexeme == ".") ||
			(currentToken.dasLexeme == "<=") ) {
				tokenCount++
				outputFile.WriteString((currentToken.dasToken + "\n"))

			// Variable Names
			} else if(currentToken.dasToken == "ID") {
				tokenCount++
				outputFile.WriteString(currentToken.dasToken + "[" + currentToken.dasType +
				"]: " + currentToken.dasLexeme + "\n")

			// Constants
			} else if((currentToken.dasType == "REAL") ||
			(currentToken.dasType == "INT")) {
				tokenCount++
				outputFile.WriteString(currentToken.dasToken +
				": " + currentToken.dasLexeme + "\n")

			// Strings (String literals, not string variable names)
			} else if(currentToken.dasToken == "STRING") {
				tokenCount++
				outputFile.WriteString(currentToken.dasToken + ": " +
				currentToken.dasLexeme + "\n")
			//And if it's not one of these, it's an error.
			//Probably. Might be those phantom empty lexemes.
			//Artifact of the implementation.
			} else {
				if(len(currentToken.dasLexeme) > 0) {
					lexicalError = true
					outputFile.WriteString("Lexical Error, unrecognized symbol " +
					currentToken.dasLexeme + "\n")
				}
			}

			//TODO: Extra Credit Part (File is set up already.)
			if((currentToken.dasLexeme != "") && (currentToken.dasToken != "Lexical_Error")) {
				bonusFile.WriteString("Token " + fmt.Sprintf("%d", tokenCount) + "\n")
				bonusFile.WriteString("\t-\tLexeme:\t" + currentToken.dasLexeme + "\n")
				bonusFile.WriteString("\t-\tType:\t" + currentToken.dasType + "\n")
				bonusFile.WriteString("\t-\tValue:\t" + currentToken.dasValue + "\n")
				bonusFile.WriteString("\t-\tToken:\t" + currentToken.dasToken + "\n")
			}

			//Wipe the string:
			currentToken.dasLexeme = ""
			currentToken.dasToken = ""
			currentToken.dasValue = ""
			currentToken.dasType = ""

		} //End of "for(len(inputString) > 0)"


	}//End of "for(err == nil)"

	goodBye(tokenCount,lexicalError, outputFileName)
}
